
package com.sampleapp.utils;

import com.sampleapp.security.Crypto;


public class GlobalVariables {
    
    private static String DBPassword;
    public static final String SECURE_KEY_RAW = "ACIJZr2DNRTZYKXeMM0fLaZn1PVWInzS";
    public static final String VECTOR_KEY_RAW = "kANYbDhaGWrazllfzFUQt0VICLkUirRw";

    private static String secureKey;
    private static String vectorKey;
    
    public static final int THREAD_POOL_COUNT = 3;
    
    public static final String[] ENCRYPTED_FIELDS = new String[]{"lastname","firstname","maternalname","dobday","dobmonth","dobyear"}; 
    
    public static final String PROPERTY_NAME_DATABASE_PORT = "3306";
        
    // DEV
    public static final String PROPERTY_NAME_DATABASE_USERNAME = "root";
    public static final String PROPERTY_NAME_DATABASE_HOST = "localhost";
    public static final String PROPERTY_NAME_DATABASE_URL_MAIN = "jdbc:mysql://localhost:3306/cps";
    public static final String PROPERTY_NAME_DATABASE_PASSWORD = "nCbo+0s3kK/hfgILVnzLJ7GlZao3M2fc/Qajr5wz4Aw=";
    
    public static void main(String[] args) {
    }
    /**
     * @return the DBPassword
     */
    public static String getDBPassword() {
        return DBPassword;
    }

    /**
     * @param aDBPassword the DBPassword to set
     */
    public static void setDBPassword(String aDBPassword) {
        DBPassword = aDBPassword;
    }

    /**
     * @return the secureKey
     */
    public static String getSecureKey() {
        return secureKey;
    }

    /**
     * @param aSecureKey the secureKey to set
     */
    public static void setSecureKey(String aSecureKey) {
        secureKey = aSecureKey;
    }

    /**
     * @return the vectorKey
     */
    public static String getVectorKey() {
        return vectorKey;
    }

    /**
     * @param aVectorKey the vectorKey to set
     */
    public static void setVectorKey(String aVectorKey) {
        vectorKey = aVectorKey;
    }

    
    
}
