
package com.sampleapp.utils;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utils {
    
    public static String generateHash(String toHash) throws UnsupportedEncodingException, NoSuchAlgorithmException {
        byte[] bytesOfMessage = toHash.getBytes("UTF-8");

        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] digest = md.digest(bytesOfMessage);
        BigInteger bigInt = new BigInteger(1, digest);
        
        return bigInt.toString(16);
    }
    
    public static String parseDate(String date, String toformat){
        String finaldate = "";
        try {
            Date newdate = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").parse(date+"T00:00:00.000Z");
            finaldate = new SimpleDateFormat(toformat).format(newdate);
        } catch (ParseException ex) {
        }
        return finaldate;
    }
    
    
    public static String parseDate(String date){
        return parseDate(date, "MMMM dd, yyyy");
    }
    
}
