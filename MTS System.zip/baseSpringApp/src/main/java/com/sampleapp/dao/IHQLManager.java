
package com.sampleapp.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public interface IHQLManager<T> {

    public List< T > fetchAll();

    public List< T > fetch(String hql);

    public List< T > fetch(String paramName,Object paramValue);

    public List<T> fetch(String sql,ArrayList<String> paramNames, ArrayList<Object> paramValues);

    public List<T> fetch(String sql,String[]paramNames, Object[] paramValues);

    public List<T> getListHQLLike(String param,String paramValue);

    public T fetchOne( Serializable id );

    public T fetchOne(String sql,String paramName,Object paramValue);

    public T fetchOne(String sql,String[] paramNames,Object[] paramValues);

    public Object getObject(String queryString);

    public long getCount();

    public void save( final T entity );

    public void saveOrUpdate(final T entity);

    public T update( final T entity );

    public void delete( final T entity );

    public void deleteById( final int id );
	
}
