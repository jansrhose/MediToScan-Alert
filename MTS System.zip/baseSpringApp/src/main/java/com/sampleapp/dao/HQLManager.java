
package com.sampleapp.dao;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Query;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Transactional
@Repository
public abstract class HQLManager<T> implements IHQLManager<T> {

    private Class<T> entityClass;

    @Autowired
    private SessionFactory sessionFactory;

    @SuppressWarnings("unchecked")
    public HQLManager() {
        entityClass = (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
    }

    @Override
    public T fetchOne(Serializable id) {
        return getCurrentSession().get(entityClass, id);
    }

    @Override
    public T fetchOne(String sql,String paramName,Object paramValue){
        Query query = getCurrentSession().createQuery(sql);
        query.setParameter(paramName, paramValue);

        return (T) query.getSingleResult();
    }


     @Override
    public T fetchOne(String sql,String[] paramNames,Object[] paramValues){
        Query query = getCurrentSession().createQuery(sql);
        for (int i = 0; i < paramNames.length; i++) {
            query.setParameter(paramNames[i], paramValues[i]);
        }

        return (T) query.getSingleResult();
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<T> fetchAll() {
        return getCurrentSession().createQuery("from " + entityClass.getName()).getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<T> fetch(String hql) {
        return getCurrentSession().createQuery(hql).getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<T> fetch(String paramName, Object paramValue) {
        return getCurrentSession()
               .createQuery("from " + entityClass.getName() + " where " + paramName + "=:" + paramName)
               .setParameter(paramName, paramValue).getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<T> fetch(String sql,ArrayList<String> paramNames, ArrayList<Object> paramValues) {
        Query query = getCurrentSession().createQuery(sql);
        for (int i = 0; i < paramNames.size(); i++) {
            query.setParameter(paramNames.get(i), paramValues.get(i));
        }

        return query.getResultList();
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<T> fetch(String sql,String[]paramNames, Object[] paramValues) {
        Query query = getCurrentSession().createQuery(sql);
        for (int i = 0; i < paramNames.length; i++) {
                query.setParameter(paramNames[i], paramValues[i]);
        }
        
        return query.getResultList();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<T> getListHQLLike(String param, String paramValue) {

        // CriteriaBuilder criteriaBuilder = getCurrentSession().getCriteriaBuilder();
        // @SuppressWarnings("unchecked")
        // CriteriaQuery<T> cq = (CriteriaQuery<T>) criteriaBuilder.createQuery();
        // Root<T> root = cq.from(entityClass);
        // Predicate predicate = criteriaBuilder.like(root.<String>get(param),
        // paramValue);
        // cq.where(predicate);
        // TypedQuery<T> query = getCurrentSession().createQuery(cq );
        //

        Criteria criteria = getCurrentSession().createCriteria(entityClass);
        criteria.add(Restrictions.like(param, paramValue, MatchMode.START));

        return criteria.list();
    }

    @Override
    public void save(final T entity) {
        getCurrentSession().save(entity);
    }

    @Override
    public void saveOrUpdate(final T entity) {
        getCurrentSession().saveOrUpdate(entity);
    }

    @Override
    @SuppressWarnings("unchecked")
    public T update(final T entity) {
        return (T) getCurrentSession().merge(entity);
    }

    @Override
    public void delete(final T entity) {
        getCurrentSession().delete(entity);
    }

    @Override
    public void deleteById(final int id) {
        final T entity = fetchOne(id);
        delete(entity);
    }

    @Override
    public Object getObject(String queryString) {
        return getCurrentSession().createQuery(queryString).getSingleResult();
    }

    @Override
    public long getCount() {
        return ((Long)getCurrentSession().createQuery("select count(*) from " + entityClass.getName()).uniqueResult());
    }
    protected final Session getCurrentSession() {
        return sessionFactory.getCurrentSession();
    }
}
