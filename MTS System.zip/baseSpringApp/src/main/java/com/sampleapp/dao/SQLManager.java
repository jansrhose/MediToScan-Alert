
package com.sampleapp.dao;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


@Repository
public abstract class SQLManager implements ISQLManager {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    @SuppressWarnings("rawtypes")
    public List getListSQL(String queryString) {
        List list = getCurrentSession().createNativeQuery(queryString).getResultList();
        return list;
    }

    @Override
    @SuppressWarnings("rawtypes")
    public List getListSQL(String queryString, Class entityClass) {
        @SuppressWarnings("unchecked")
        List list = null;
        try{
            list = getCurrentSession().createNativeQuery(queryString,entityClass).getResultList();
        }catch(Exception e){
            System.out.println(e);
        }
        return list;
    }

    @Override
    @SuppressWarnings("rawtypes")
    public List getListSQL(String queryString, String paramName, Object paramValue) {
        List list = getCurrentSession().createNativeQuery(queryString)
                    .setParameter(paramName, paramValue).getResultList();
        return list;
    }

    @Override
    @SuppressWarnings({"rawtypes","unchecked"})
    public List getListSQL(String queryString, String paramName, Object paramValue,Class entityClass) {
        List list = getCurrentSession().createNativeQuery(queryString,entityClass)
                    .setParameter(paramName, paramValue).getResultList();
        return list;
    }


    @Override
    @SuppressWarnings("rawtypes")	
    public List getListSQL(String sql, String[] params, Object[] paramValues) {
        Query  query = getCurrentSession().createNativeQuery(sql);
        for (int i = 0; i < params.length; i++) {
            query.setParameter(params[i], paramValues[i]);
        }
        return query.getResultList();
    }

    @Override
    @SuppressWarnings({"rawtypes","unchecked"})
    public List getListSQL(String sql, ArrayList params, ArrayList paramValues, Class entityClass) {
        Query query = getCurrentSession().createNativeQuery(sql,entityClass);
        for (int i = 0; i < params.size(); i++) {
            query.setParameter(params.get(i).toString(), paramValues.get(i));
        }
        List list = query.getResultList();
        return list;
    }

    @Override
    @SuppressWarnings("rawtypes")
    public List getListSQL(String sql, ArrayList params, ArrayList paramValues) {
        Query query = getCurrentSession().createNativeQuery(sql);
        for (int i = 0; i < params.size(); i++) {
            query.setParameter(params.get(i).toString(), paramValues.get(i));
        }
        return query.getResultList();
    }


    @Override
    @SuppressWarnings({"rawtypes","unchecked"})
    public List getListSQL(String sql, String[] params, String[] paramValues, Class entityClass) {
        Query query = getCurrentSession().createNativeQuery(sql,entityClass);
        for (int i = 0; i < params.length; i++) {
            query.setParameter(params[i].toString(), paramValues[i]);
        }
        return query.getResultList();
    }

    @Override
    @SuppressWarnings("rawtypes")
    public List getListSQL(String sql, int firstResult, int maxResult) {
        Query query = getCurrentSession().createNativeQuery(sql);
        query.setFirstResult(firstResult);
        query.setMaxResults(maxResult);
        return query.getResultList();
    }

    @Override
    @SuppressWarnings("rawtypes")
    public List getListSQL(String sql, String paramName, Object paramValue, int firstResult, int maxResult) {
        Query query = getCurrentSession().createNativeQuery(sql);
        query.setParameter(paramName, paramValue);
        query.setFirstResult(firstResult);
        query.setMaxResults(maxResult);
        return query.getResultList();
    }

    @Override
    @SuppressWarnings("rawtypes")
    public List getListSQL(String sql, String[] paramNames, Object[] paramValues, int firstResult, int maxResult) {
        Query query = getCurrentSession().createNativeQuery(sql);
        for(int i =0;i< paramNames.length;i++) {
            query.setParameter(paramNames[i], paramValues[i]);
        }

        query.setFirstResult(firstResult);
        query.setMaxResults(maxResult);

        return query.getResultList();
    }

    @Override
    public Object executeScalarSQL(String queryString) {
        return getCurrentSession().createNativeQuery(queryString).getSingleResult();
    }

    @Override
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public Object executeScalarSQL(Class entityClass, String queryString, String paramName, Object parameterValue) {
        Query query = getCurrentSession().createNativeQuery(queryString,entityClass);
        query.setParameter(paramName, parameterValue);
        return query.getSingleResult();
    }

    @Override
    public Object executeScalarSQL(String queryString, String paramName, Object parameterValue) {
        Query query =  getCurrentSession().createNativeQuery(queryString);
        query.setParameter(paramName, parameterValue);
        return query.getSingleResult();
    }

    @Override
    public Object executeScalarSQL(String queryString, String[] paramNames, Object[] parameterValues) {
        Query query = getCurrentSession().createNativeQuery(queryString);
        for(int i = 0;i < paramNames.length;i++) {
            query.setParameter(paramNames[i], parameterValues[i]);
        }
        return query.getSingleResult();
    }

    @Override
    public Object executeScalarSQL(String queryString, String[] paramNames, Object[] parameterValues,Class entityClass) {
        Query query = getCurrentSession().createNativeQuery(queryString,entityClass);
        for(int i = 0;i < paramNames.length;i++) {
            query.setParameter(paramNames[i], parameterValues[i]);
        }
        return query.getSingleResult();
    }

    @Override
    @SuppressWarnings("rawtypes")
    public Object executeScalarSQL(String queryString,  ArrayList paramNames, ArrayList parameterValues) {
        Query query = getCurrentSession().createNativeQuery(queryString);
        for(int i = 0;i < paramNames.size();i++) {
            query.setParameter(paramNames.get(i).toString(), parameterValues.get(i));
        }
        return query.getSingleResult();
    }

    @Override
    public int executeQuery(String sql) {
        Query query = getCurrentSession().createNativeQuery(sql);
        return query.executeUpdate();
    }

    @Override
    public int executeQuery(String sql, String paramName, Object paramValue) {
        Query query = getCurrentSession().createNativeQuery(sql).setParameter(paramName,paramValue);
        return query.executeUpdate();
    }

    @Override
    public int executeQuery(String sql, String[] paramName, Object[] paramValue) {
        Query query = getCurrentSession().createNativeQuery(sql);
        for(int i=0;i<paramName.length;i++) {
                query.setParameter(paramName[i], paramValue[i]);
        }
        return query.executeUpdate();
    }

    @Override
    @SuppressWarnings("rawtypes")
    public int executeQuery(String sql, ArrayList paramNames, ArrayList paramValues) {
        Query query = getCurrentSession().createNativeQuery(sql);
        for(int i=0;i<paramNames.size();i++) {
                query.setParameter(paramNames.get(i).toString(), paramValues.get(i));
        }
        return query.executeUpdate();
    }


    @Override
    public void save(Object object) {
        getCurrentSession().save(object);
    }

    @Override
    public void saveOrUpdate(Object object) {
        getCurrentSession().saveOrUpdate(object);
    }

    protected final Session getCurrentSession(){
        try {
            return sessionFactory.getCurrentSession();
        }catch(Exception x) {
            System.out.println(x);
        }

        return null;
    }
}
