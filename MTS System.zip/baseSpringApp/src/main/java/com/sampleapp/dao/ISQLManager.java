
package com.sampleapp.dao;

import java.util.ArrayList;
import java.util.List;

public interface ISQLManager {

    @SuppressWarnings("rawtypes")
    public List getListSQL(String queryString);

    @SuppressWarnings("rawtypes")
    public List getListSQL(String queryString, Class entityClass);

    @SuppressWarnings("rawtypes")
    public List getListSQL(String queryString, String paramName, Object parameterValue);
    
    @SuppressWarnings("rawtypes")
    public List getListSQL(String query, int paramName, Class entityClass);
    
    @SuppressWarnings("rawtypes")
    public List getListSQL(String queryString, String paramName, Object paramValue,Class entityClass);

    @SuppressWarnings("rawtypes")
    public List getListSQL(String sql, String[] params, Object[] paramValues);

    @SuppressWarnings("rawtypes")
    public List getListSQL(String sql, ArrayList params, ArrayList paramValues, Class entityClass);

    @SuppressWarnings("rawtypes")
    public List getListSQL(String sql, ArrayList params, ArrayList paramValues);

    @SuppressWarnings("rawtypes")
    public List getListSQL(String sql, String[] params, String[] paramValues, Class entityClass);

    @SuppressWarnings("rawtypes")
    public List getListSQL(String Sql, int firstResult, int maxResult);

    @SuppressWarnings("rawtypes")
    public List getListSQL(String Sql, String paramName, Object paramValue, int firstResult, int maxResult);

    @SuppressWarnings("rawtypes")
    public List getListSQL(String Sql, String[] paramNames, Object[] paramValues, int firstResult, int maxResult);

    public Object executeScalarSQL(String queryString);

    @SuppressWarnings("rawtypes") 
    public Object executeScalarSQL(Class entityClass,String queryString, String paramName, Object parameterValue);

    public Object executeScalarSQL(String queryString, String paramName, Object parameterValue);

    public Object executeScalarSQL(String queryString, String[] paramNames, Object[] parameterValues);


    public Object executeScalarSQL(String queryString, String[] paramNames, Object[] parameterValues,Class entityClass);

    @SuppressWarnings("rawtypes")
    public Object executeScalarSQL(String queryString,  ArrayList paramNames, ArrayList parameterValues);

    public int executeQuery(String sql);

    public int executeQuery(String sql,String paramName,Object paramValue);

    public int executeQuery(String sql,String[] paramName,Object[] paramValue);
    
    @SuppressWarnings("rawtypes")
    public int executeQuery(String sql,ArrayList paramNames,ArrayList paramValues);
    
    public void save(Object object);
    
    public void saveOrUpdate(Object object);
    
    public int executeUpdate(String sql);
}
