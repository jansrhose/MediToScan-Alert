
package com.sampleapp.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.SecondaryTables;
import javax.persistence.Table;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity
@Table(name="scannedqr")
@SecondaryTables({
    @SecondaryTable(name = "users", pkJoinColumns=@PrimaryKeyJoinColumn(name="uid")),
    @SecondaryTable(name = "medical_records", pkJoinColumns=@PrimaryKeyJoinColumn(name="idscan"))              
})

public class EntityScannedQR  implements Serializable {

   
    @Id
    @Column(name="SID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int sid;
    
    @Column(name="UID")
    private int uid;
    
    @Column(name="IDSCAN")
    private int idscan;
    
    @Column(name="DATE")
    private String date;
    
    @Column(name="LATITUDE")
    private String latitude;
    
    @Column(name="LONGITUDE")
    private String longitude;
    
    @Column(name="ADDRESS")
    private String address;
    
    @Column(name="SITUATION")
    private String situation;
    
    @Column(name="CATEGORY")
    private String category;
    
    @Column(name="LID")
    private int lid;
    
    @Column(name="DONE")
    private int done;
    
//    @Column(name="DISTANCE")
//    private int distance;
    
    @OneToOne
    @NotFound(action = NotFoundAction.IGNORE)
    @JoinColumn(name="idscan", referencedColumnName="uid", table = "users", insertable = false, updatable = false)
    private Users idScanned;
    
    @OneToOne
    @NotFound(action = NotFoundAction.IGNORE)
    @JoinColumn(name="uid", referencedColumnName="uid", table = "users", insertable = false, updatable = false)
    private Users scannedBy;
    
    @OneToOne
    @NotFound(action = NotFoundAction.IGNORE)
    @JoinColumn(name="idscan", referencedColumnName="uid", table = "medical_records", insertable = false, updatable = false)
    private MedicalRecord medicalRecord;
     
//    public int getDistance() {
//        return distance;
//    }
//
//    public void setDistance(int distance) {
//        this.distance = distance;
//    }
    
     public int getDone() {
        return done;
    }

    public void setDone(int done) {
        this.done = done;
    }
    
    public int getLid() {
        return lid;
    }

    public void setLid(int lid) {
        this.lid = lid;
    }
    
    public int getSid() {
        return sid; 
    }

    public void setSid(int sid) {
        this.sid = sid;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public int getIdscan() {
        return idscan;
    }

    public void setIdscan(int idscan) {
        this.idscan = idscan;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
        public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
    
    
    
    /**
     * @return the scannedBy
     */
    public Users getScannedBy() {
        return scannedBy;
    }

    /**
     * @param scannedBy the scannedBy to set
     */
    public void setScannedBy(Users scannedBy) {
        this.scannedBy = scannedBy;
    }

    /**
     * @return the idScanned
     */
    public Users getIdScanned() {
        return idScanned;
    }

    /**
     * @param idScanned the idScanned to set
     */
    public void setIdScanned(Users idScanned) {
        this.idScanned = idScanned;
    }

    /**
     * @return the situation
     */
    public String getSituation() {
        return situation;
    }

    /**
     * @param situation the situation to set
     */
    public void setSituation(String situation) {
        this.situation = situation;
    }

    /**
     * @return the medicalRecord
     */
    public MedicalRecord getMedicalRecord() {
        return medicalRecord;
    }

    /**
     * @param medicalRecord the medicalRecord to set
     */
    public void setMedicalRecord(MedicalRecord medicalRecord) {
        this.medicalRecord = medicalRecord;
    }

   
}
