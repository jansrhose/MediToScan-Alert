package com.sampleapp.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="users")
public class Users implements Serializable {
    
    @Id
    @Column(name="UID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int uid;
    
    @Column(name="USERTYPE")
    private String usertype;
    
    @Column(name="PIC")
    private String pic;
    
    @Column (name="FIRSTNAME")
    private String firstname;
    
    @Column (name="MIDDLENAME")
    private String middlename;
    
    @Column (name="LASTNAME")
    private String lastname;
    
    @Column (name="GENDER")
    private String gender;
    
    @Column (name="BIRTHDATE")
    private String birthdate;
    
    @Column (name="ADDRESS")
    private String address;
    
    @Column (name="CONTACT")
    private String contact;
    
    @Column (name="EMAIL")
    private String email;
    
    @Column (name="QUESTION")
    private String question;
    
    @Column (name="ANSWER")
    private String answer;
    
    @Column (name="PASSWORD")
    private String password;
    
    @Column (name="ECNAME")
    private String ecname;
    
    @Column (name="ECCONTACT")
    private String eccontact;
    
    @Column (name="RELATIONSHIP")
    private String relationship;


    @Column (name="STATUS")
    private int status;

    
    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getUsertype() {
        return usertype;
    }

    public void setUsertype(String usertype) {
        this.usertype = usertype;
    }

    public String getPic() {
        return pic;
    }

    public void setPic(String pic) {
        this.pic = pic;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstName) {
        this.firstname = firstName;
    }

    public String getMiddlename() {
        return middlename;
    }

    public void setMiddlename(String middleName) {
        this.middlename = middleName;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastName) {
        this.lastname = lastName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }
    
    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
     public String getEcname() {
        return ecname;
    }

    public void setEcname(String ecname) {
        this.ecname = ecname;
    }

    public String getEccontact() {
        return eccontact;
    }

    public void setEccontact(String eccontact) {
        this.eccontact = eccontact;
    }

    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

}
