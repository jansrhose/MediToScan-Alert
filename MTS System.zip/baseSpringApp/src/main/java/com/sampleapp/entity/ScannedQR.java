
package com.sampleapp.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="scannedqr")
public class ScannedQR  implements Serializable {
    
    @Id
    @Column(name="SID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int sid;
    
    @Column(name="UID")
    private int uid;
    
    @Column(name="IDSCAN")
    private int idscan;
    
    @Column(name="DATE")
    private String date;
    
    @Column(name="LATITUDE")
    private String latitude;
    
    @Column(name="LONGITUDE")
    private String longitude;
    
    @Column(name="ADDRESS")
    private String address;
    
    @Column(name="LID")
    private int lid;

    @Column(name="SITUATION")
    private String situation;
    
    @Column(name="CATEGORY")
    private String category;
    
    @Column(name="DONE")
    private int done;
    
    @Column(name="DISTANCE")
    private String distance;

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public int getDone() {
        return done;
    }

    public void setDone(int done) {
        this.done = done;
    }
    
    public int getLid() {
        return lid;
    }

    public void setLid(int lid) {
        this.lid = lid;
    }
    
    public int getSid() {
        return sid; 
    }

    public void setSid(int sid) {
        this.sid = sid;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public int getIdscan() {
        return idscan;
    }

    public void setIdscan(int idscan) {
        this.idscan = idscan;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
    public String getSituation() {
        return situation;
    }

    public void setSituation(String situation) {
        this.situation = situation;
    }
    
    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
