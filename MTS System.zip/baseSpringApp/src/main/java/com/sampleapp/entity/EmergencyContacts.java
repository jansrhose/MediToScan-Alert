/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sampleapp.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Jeck
 */
@Entity
@Table(name="emergency_contacts")
public class EmergencyContacts implements Serializable{
    @Id 
 @Column (name="ECID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int ecid; 
    
    @Column (name="UID")
    private int uid;
        
    @Column (name="NAME")
    private String name;
    
        
    @Column (name="RELATIONSHIP")
    private String relationship;
    
        
    @Column (name="CONTACT")
    private String contact;

    public int getEcid() {
        return ecid;
    }

    public void setEcid(int ecid) {
        this.ecid = ecid;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRelationship() {
        return relationship;
    }

    public void setRelationship(String relationship) {
        this.relationship = relationship;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }
}

