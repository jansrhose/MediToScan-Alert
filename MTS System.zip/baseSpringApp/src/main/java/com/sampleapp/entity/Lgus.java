/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sampleapp.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="lgus")
public class Lgus implements Serializable {
    
    @Id
    @Column(name="LID")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int lid;
    
    @Column(name="REGION")
    private String region;
    
    @Column(name="CITY")
    private String city;
    
    @Column(name="BARANGAY")
    private String barangay;
    
    @Column(name="CONTACT")
    private String contact;
    
    @Column(name="EMAIL")
    private String email;
    
    @Column (name="QUESTION")
    private String question;
    
    @Column (name="ANSWER")
    private String answer;
    
    @Column(name="PASSWORD")
    private String password;

    public int getLid() {
        return lid;
    }

    public void setLid(int lid) {
        this.lid = lid;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getBarangay() {
        return barangay;
    }

    public void setBarangay(String barangay) {
        this.barangay = barangay;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
     public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }
    
    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Users convertToUsers(Lgus lgu) {
        Users u = new Users();
        u.setAnswer(lgu.getAnswer());
        u.setEmail(lgu.getEmail());
        u.setContact(lgu.getContact());
        u.setPassword(lgu.getPassword());
        u.setQuestion(lgu.getQuestion());
        u.setUsertype("lgu");
        u.setUid(lgu.getLid());
        return u;
    }
    
}
