
package com.sampleapp.references.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="allprov")
public class Allprov {

    @Id
    @Column(name="prv")
    private String prv;

    @Column(name="area")
    private String area;

    @Column(name="CODE_REGION")
    private String codeRegion;

    @Column(name="REGION")
    private String region;

    public Allprov() {
    }

    public String getPrv() {
        return prv;
    }

    public void setPrv(String prv) {
        this.prv = prv;
    }

    public String getArea() {
        return area;
    }
  
    public void setArea(String area) {
        this.area = area;
    }

    /**
     * @return the codeRegion
     */
    public String getCodeRegion() {
        return codeRegion;
    }

    /**
     * @param codeRegion the codeRegion to set
     */
    public void setCodeRegion(String codeRegion) {
        this.codeRegion = codeRegion;
    }

    /**
     * @return the region
     */
    public String getRegion() {
        return region;
    }

    /**
     * @param region the region to set
     */
    public void setRegion(String region) {
        this.region = region;
    }
    
		
}





