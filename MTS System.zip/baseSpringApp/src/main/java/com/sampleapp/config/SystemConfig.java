
package com.sampleapp.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;


@Configuration
@PropertySource({"classpath:system.properties"})
public class SystemConfig {
  public static final String PROPERTY_NAME_SOURCE_FILE = "system.storefile";
  
  public static final String PROPERTY_NAME_CERT_PATH = "system.certpath";
  
  public static final String PROPERTY_NAME_SECKEY = "system.seckey";
  
  public static final String PROPERTY_NAME_VECKEY = "system.veckey";
}
