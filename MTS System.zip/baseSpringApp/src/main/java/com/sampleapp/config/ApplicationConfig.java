
package com.sampleapp.config;

import java.io.IOException;
import java.util.Properties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Import;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.handler.SimpleMappingExceptionResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import com.sampleapp.controller.ExceptionHandlerController;
import com.sampleapp.listeners.RequestInteceptor;


@Configuration
@ComponentScan(basePackages = {"com.sampleapp"})
@Import({DataSourceConfig.class})
@EnableTransactionManagement
@EnableAspectJAutoProxy
@EnableWebMvc
public class ApplicationConfig implements WebMvcConfigurer {
    
  public void addResourceHandlers(ResourceHandlerRegistry registry) {
    registry.addResourceHandler(new String[] { "/resources/**" }).addResourceLocations(new String[] { "/resources/" });
  }
  
  public void addInterceptors(InterceptorRegistry registry) {
    registry.addInterceptor((HandlerInterceptor)new RequestInteceptor());
  }
  
  @Bean
  public ViewResolver viewResolver() {
    InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
    viewResolver.setPrefix("/WEB-INF/views/");
    viewResolver.setSuffix(".jsp");
    return (ViewResolver)viewResolver;
  }
  
  @Bean
  public SimpleMappingExceptionResolver exceptionResolver() {
    SimpleMappingExceptionResolver ex = new SimpleMappingExceptionResolver();
    Properties a = new Properties();
    a.put(ExceptionHandlerController.class, "error");
    ex.setExceptionMappings(a);
    return ex;
  }
  
  @Bean(name = {"multipartResolver"})
  public CommonsMultipartResolver getResolver() throws IOException {
    CommonsMultipartResolver resolver = new CommonsMultipartResolver();
    resolver.setMaxUploadSizePerFile(1110485760L);
    return resolver;
  }
}
