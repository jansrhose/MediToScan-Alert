
package com.sampleapp.config;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import javax.servlet.ServletContext;
import javax.sql.DataSource;
import org.apache.commons.dbcp.BasicDataSource;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBuilder;
import com.sampleapp.dao.DbContextHolder;
import com.sampleapp.dao.RoutingDataSource;
import com.sampleapp.security.Crypto;
import com.sampleapp.utils.GlobalVariables;



@Configuration
@PropertySource("classpath:jdbc.properties")
public class DataSourceConfig {

    @Autowired
    ServletContext context;
    @Autowired
    ApplicationContext appContext;
    public static final String PROPERTY_NAME_DATABASE_DRIVER = "jdbc.driverClassName";
    public static final String PROPERTY_NAME_DATABASE_PASSWORD = "jdbc.password";
    public static final String PROPERTY_NAME_DATABASE_URL_MAIN = "jdbc.databaseurlMain";
    public static final String PROPERTY_NAME_DATABASE_USERNAME = "jdbc.username";
    public static final String PROPERTY_NAME_DATABASE_URL = "jdbc.databaseurl";
    public static final String PROPERTY_NAME_DATABASE_HOST = "jdbc.host";
    public static final String PROPERTY_NAME_DATABASE_PORT = "jdbc.port";
    public static final String PROPERTY_NAME_HIBERNATE_DIALECT = "jdbc.dialect";
    public static final String PROPERTY_NAME_HIBERNATE_SHOW_SQL = "jdbc.show_sql";
    

    @Bean(name = "dataSource")
    public AbstractRoutingDataSource getDataSource() {
        RoutingDataSource routingDataSource = new RoutingDataSource();
        routingDataSource.setDefaultTargetDataSource(dataSourceMain());
        Map<Object, Object> targetDataSource = new HashMap<>();
        targetDataSource.put(DbContextHolder.DbType.SampleDB, dataSourceMain());
        routingDataSource.setTargetDataSources(targetDataSource);
        routingDataSource.afterPropertiesSet();

        return routingDataSource;
    }

    @Bean
    public DataSource dataSourceMain() {
        BasicDataSource dataSource = new BasicDataSource();
        dataSource.setUrl("jdbc:mysql://"+GlobalVariables.PROPERTY_NAME_DATABASE_HOST+":3306/capstone");
        setDataSourceProperties(dataSource);
        return dataSource;
    }

    private void setDataSourceProperties(BasicDataSource dataSource) {
        try {
            dataSource.setDriverClassName("com.mysql.jdbc.Driver");
            dataSource.setUsername(GlobalVariables.PROPERTY_NAME_DATABASE_USERNAME);
            GlobalVariables.setSecureKey(GlobalVariables.SECURE_KEY_RAW);
            GlobalVariables.setVectorKey(GlobalVariables.VECTOR_KEY_RAW);
            String decPass = new Crypto().decryptString(GlobalVariables.PROPERTY_NAME_DATABASE_PASSWORD);
            
            dataSource.setPassword(decPass);
            GlobalVariables.setDBPassword(decPass);
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    @Bean(name = "sessionFactory")
    public SessionFactory getSessionFactory(javax.sql.DataSource dataSource) {
        LocalSessionFactoryBuilder sessionBuilder = new LocalSessionFactoryBuilder(dataSource);
        sessionBuilder.scanPackages(new String[]{"com.sampleapp.entity"});
        sessionBuilder.addProperties(getHibernateProperties());
        return sessionBuilder.buildSessionFactory();
    }

    private Properties getHibernateProperties() {
        Properties properties = new Properties();
        properties.put("hibernate.show_sql", "false");
        properties.put("hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect");
        return properties;
    }

    @Autowired
    @Bean(name = "transactionManager")
    public HibernateTransactionManager getTransactionManager(
            SessionFactory sessionFactory) {
        HibernateTransactionManager transactionManager = new HibernateTransactionManager(
                sessionFactory);

        return transactionManager;
    }

}
