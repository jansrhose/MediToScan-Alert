package com.sampleapp.controller;

import com.sampleapp.common.service.IRawTypeService;
import com.sampleapp.entity.EntityScannedQR;
import com.sampleapp.entity.ScannedQR;
import com.sampleapp.entity.Users;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/dashboard")
public class DashboardController {
    
    @Autowired
    IRawTypeService iRawTypeService;
    
    @Autowired
    HttpSession session;
    
    @GetMapping("/show")
    public String index(){
        return "dashboard";
    }
    
    @GetMapping("/emergencyHistory")
    public String history(){
        return "emergencylogs";
    }
    
    @GetMapping("/pendingEmergency")
    public String pending(){
        return "pendinglogs";
    }
    
    @GetMapping("/getAlertStats")
    @ResponseBody
    public Map<String, String> getAlertStats(){
        List<String[]> medicals = iRawTypeService.getListSQL("select monthval, countmonth from (SELECT mid(date(STR_TO_DATE(S.date, concat('%a %b %d %H:%i:%S ',mid(s.date,21,3),' %Y'))),6,2) as monthval, count(*) as countmonth FROM capstone.scannedqr s where done !='0' and category = 'Medical' group by mid(date(STR_TO_DATE(S.date, concat('%a %b %d %H:%i:%S ',mid(s.date,21,3),' %Y'))),6,2)) m");
        
        List<String[]> accidents = iRawTypeService.getListSQL("select monthval, countmonth from (SELECT mid(date(STR_TO_DATE(S.date, concat('%a %b %d %H:%i:%S ',mid(s.date,21,3),' %Y'))),6,2) as monthval, count(*) as countmonth FROM capstone.scannedqr s where done !='0' and category = 'Accident' group by mid(date(STR_TO_DATE(S.date, concat('%a %b %d %H:%i:%S ',mid(s.date,21,3),' %Y'))),6,2)) m");
        
        Map<String, String> res = new HashMap<>();
        for(Object[] m: medicals){
            res.put("M"+m[0], m[1].toString());
        }
        
        for(Object[] a: accidents){
            res.put("A"+a[0], a[1].toString());
        }
        
        return res;
    }
    
    @GetMapping("/getAlerts")
    @ResponseBody
    public List<EntityScannedQR> getAlerts(){
        return iRawTypeService.getListSQL("SELECT s.*, u.*,l.*, m.* FROM scannedqr s LEFT JOIN users u ON s.uid = u.uid LEFT JOIN users l ON s.idscan = l.uid LEFT JOIN medical_records m ON s.uid = m.uid WHERE s.LID = '0' ORDER BY STR_TO_DATE(S.date, concat('%a %b %d %H:%i:%S ',mid(s.date,21,3),' %Y')) DESC;", EntityScannedQR.class);
    }  
    
    @GetMapping("/getOwnedAlerts")
    @ResponseBody
    public List<ScannedQR> getOwnedAlerts(){
        Users u =(Users) session.getAttribute("currentUser");
        return iRawTypeService.getListSQL("SELECT s.*, u.lastname, u.firstname, u.middlename, u.middlename, m.illness, m.allergies, m.medication FROM scannedqr s LEFT JOIN users u ON s.uid = u.uid LEFT JOIN medical_records m ON s.uid = m.uid where LID ='"+u.getUid()+"' and done='0'", EntityScannedQR.class);
    } 
    
    @GetMapping("/acceptAlert")
    @ResponseBody
    public boolean acceptAlert(@RequestParam("sid")String sid, @RequestParam("distance") String distance){
        List<ScannedQR> sq = iRawTypeService.getListSQL("SELECT * FROM scannedqr where sid = '"+sid+"'", ScannedQR.class);
        
        if(sq.size() > 0){
            Users u =(Users) session.getAttribute("currentUser");
            ScannedQR s = sq.get(0);
            s.setLid(u.getUid());
            s.setDistance(distance);
            iRawTypeService.saveOrUpdate(s);
            return true;
        }
        
        return false;
    }
    
    @GetMapping("/doneAlert")
    @ResponseBody
    public boolean doneAlert(@RequestParam("sid") String sid) {
        List<ScannedQR> sq = iRawTypeService.getListSQL("SELECT * FROM scannedqr where sid = '"+sid+"'", ScannedQR.class);
        
            if (sq.size() > 0) {
                ScannedQR s = sq.get(0);

                if (s.getDone() == 0) {
                    s.setDone(1);
                    iRawTypeService.saveOrUpdate(s);
                    return true;
                }
            }
            return false;
    }
    
    @GetMapping("/reportHoax")
    @ResponseBody
    public boolean reportHoax(@RequestParam("sid") String sid) {
        List<ScannedQR> sq = iRawTypeService.getListSQL("SELECT * FROM scannedqr where sid = '"+sid+"'", ScannedQR.class);
        
            if (sq.size() > 0) {
                ScannedQR s = sq.get(0);

                if (s.getDone() == 0) {
                    s.setDone(2);
                    iRawTypeService.saveOrUpdate(s);
                    return true;
                }
            }
            return false;
    }

    @GetMapping("/getDoneAlerts")
    @ResponseBody
    public List<ScannedQR> getDoneAlerts(){
        Users u =(Users) session.getAttribute("currentUser");
        return iRawTypeService.getListSQL("SELECT s.*, u.lastname, u.firstname, u.middlename, u.middlename, m.illness, m.allergies, m.medication FROM scannedqr s LEFT JOIN users u ON s.uid = u.uid LEFT JOIN medical_records m ON s.uid = m.uid where s.DONE = '1' and LID ='"+u.getUid()+"'", EntityScannedQR.class);
    } 
    
    @GetMapping("/getReport")
    @ResponseBody
    public List<ScannedQR> getReport(){
        Users u =(Users) session.getAttribute("currentUser");
        return iRawTypeService.getListSQL("SELECT s.*, u.lastname, u.firstname, u.middlename, u.middlename, m.illness, m.allergies, m.medication FROM scannedqr s LEFT JOIN users u ON s.uid = u.uid LEFT JOIN medical_records m ON s.uid = m.uid where s.DONE = '2' and LID ='"+u.getUid()+"'", EntityScannedQR.class);
    } 

}
