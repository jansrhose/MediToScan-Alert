/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.sampleapp.controller;

import com.sampleapp.common.service.IRawTypeService;
import com.sampleapp.entity.MedicalRecord;
import com.sampleapp.entity.ScannedQR;
import com.sampleapp.entity.Users;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
@RequestMapping(value="QR")
public class QrReaderController {
    @Autowired
    private IRawTypeService irawTypeService;
    
    @Autowired
    private HttpSession session;
    
    @GetMapping(value = "/QRDisplay")
    public String scanQRPage (Model model){
        return "qrscan";
    }
    
    @ResponseBody
    @GetMapping (value ="/getAlertStatus")
    public ScannedQR getAlertStatus(@RequestParam("sID") String idScan){
        String query = "SELECT * FROM scannedqr WHERE idscan=:idscan order by SID desc limit 1";
        List<ScannedQR> search = irawTypeService.getListSQL(query, new String[]{"idscan"},new String[]{idScan}, ScannedQR.class);
        if(search.isEmpty()){
            return null;
        }
        return search.get(0);
    }
    
    
    
    @GetMapping (value ="/ScanQR")
    public String qrContentDisplay (Model model, @RequestParam ("uid") String scannedID, @RequestParam("latitude") String latitude, @RequestParam("longitude") String longitude, @RequestParam("address") String address, @RequestParam("situation") String situation, @RequestParam("category") String category) {
        String query = "SELECT * FROM users WHERE UID=:uid";
        String medquery = "SELECT * FROM medical_records WHERE UID=:uid";
        Class userclass = Users.class;
        Class medclass = MedicalRecord.class;
        List<Users> search = new ArrayList<>();
        List<MedicalRecord> medsearch = new ArrayList<>();
        Users currentUser = (Users) session.getAttribute("currentUser");
        search = irawTypeService.getListSQL(query, new String[]{"uid"},new String[]{scannedID}, userclass);
        medsearch = irawTypeService.getListSQL(medquery, new String[]{"uid"}, new String[]{scannedID}, medclass);
        String message = "success";
        String page = "qrscan";
        if(search.size() > 0 ){
            Users scannedQROfUser = search.get(0);
            model.addAttribute("resultQR",scannedQROfUser);
            //save alert
            ScannedQR sQR = new ScannedQR();
            sQR.setCategory(category);
            sQR.setSituation(situation);
            sQR.setDate(new Date().toString());
            sQR.setUid(currentUser.getUid());
            sQR.setIdscan(Integer.parseInt(scannedID));
            sQR.setLatitude(latitude);
            sQR.setLongitude(longitude);
            sQR.setAddress(address);
            if(medsearch.size() > 0){
                model.addAttribute("medQR", medsearch.get(0));
            }
            try{
                //redirect depending on the logged in user
                String usertype = currentUser.getUsertype();
                switch(usertype){
                    case "patient":
                        irawTypeService.save(sQR);
                        page = "profileUser";
                        break;
                    case "practitioner":
                        model.addAttribute("scannedQR", sQR);
                        irawTypeService.save(sQR);
                        page = "showscanneddetails";
                        break;
                }
                
            }catch(Exception e){
                message = "errorsave";
                System.out.println(e);
            }
            
//            irawTypeService.saveOrUpdate(search);
        }else{
            message ="UID NOT FOUND!";
        }
        model.addAttribute("resultmessage", message);
        
        return page;
    }
    
}
