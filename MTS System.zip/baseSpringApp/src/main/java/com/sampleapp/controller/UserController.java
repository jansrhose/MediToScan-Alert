package com.sampleapp.controller;

import com.sampleapp.common.service.IRawTypeService;
import com.sampleapp.entity.EmergencyContacts;
import com.sampleapp.entity.Feedback;
import com.sampleapp.entity.Lgus;
import com.sampleapp.entity.MedicalRecord;
import com.sampleapp.entity.Users;
import com.sampleapp.security.Crypto;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping({"/User"})
public class UserController {
    @Autowired
    private IRawTypeService irawTypeService;

    @Autowired
    private HttpSession session;
    
    @Autowired
    private JavaMailSender emailSender;
    
    public static final String MAIL_SERVER_ADDRESS = "jansrhose@yahoo.com";

    @GetMapping("/verifyuser")
    public String verifyUser(@RequestParam("uid") String uid, Model themodel){
        List<Users> u = irawTypeService.getListSQL("SELECT * FROM users where uid=:id","id",uid, Users.class);
        String msg = "";
        if(u.size() > 0){
            Users user = u.get(0);
            if(user.getStatus() == 0){
                user.setStatus(1);
                irawTypeService.saveOrUpdate(user);
                msg ="emailsuccessfullyverified";
            }else{
                msg="alreadyverified";
            }
        }else{
            msg = "notexists";
        }
        themodel.addAttribute("CPresult",msg);
        return "login";
    }
    
    @GetMapping("/testmail")
    @ResponseBody
    public String testmail(){
        JavaMailSender jms = getJavaMailSender();
        
        sendSimpleMessage(jms, "jansellechavez07@gmail.com", "test subject", "test body");
        return "success";
    }
    //User Registration
    @PostMapping(value = "/registrationUser")
    public String submitForm(@ModelAttribute Users user, Model model) {
        List<Users> u = irawTypeService.getListSQL("SELECT * FROM users where email=:e","e",user.getEmail(), Users.class);
        String msg = "";
        String result = null;
            
        if(u.size() == 0){
            //Password Encryption
            String pw = user.getPassword();
            String ans = user.getAnswer();
            Crypto c = new Crypto();      
            user.setPassword(c.encryptString(pw));
            user.setAnswer(c.encryptString(ans));

            //add checker if email exists

            try{
                irawTypeService.saveOrUpdate(user);
                List<Users> u2 = irawTypeService.getListSQL("SELECT * FROM users where email=:e","e",user.getEmail(), Users.class);
                Users uv = u2.get(0);
                 String activationLink = "http://mts-tip.online/mts/User/verifyuser?uid="+uv.getUid();
                result = "You are successfully REGISTERED! Verify your email first to LOGIN.";
                JavaMailSender jms = getJavaMailSender();
                sendSimpleMessage(jms, user.getEmail(), "MTS Email Verification",  "Click this link to verify: " + activationLink);

                 
            }catch(Exception e){
                System.out.println(e);
            }
        }else{
            result="Email is already in use.";
        }
        
        
        
        model.addAttribute("CPresult",result);
        return "login"; 
    }
    
    //LGU Registration
    @PostMapping(value = "/registrationLGU")
    public String submitForm(@ModelAttribute Lgus lgu, Model model) {
        String result = null;
        //Password Encryption
        String pw = lgu.getPassword();
        String ans = lgu.getAnswer();
        Crypto c = new Crypto();      
        lgu.setPassword(c.encryptString(pw));
        lgu.setAnswer(c.encryptString(ans));

        try{
            result = "You are successfully REGISTERED! You can now Login.";
            irawTypeService.saveOrUpdate(lgu); 
        }catch(Exception e){
            System.out.println(e);
        }
        
        model.addAttribute("CPresult",result);
        return "login"; 
    }
    
    //Feedback
    @PostMapping(value = "/inputFeedback")
    public String submitForm(@ModelAttribute Feedback newFeed, Model themodel) {
        String result = null;
        try{
            irawTypeService.saveOrUpdate(newFeed); 
            result = "Thank you for your feedback! Your input has been successfully sent and is greatly appreciated.";
        }catch(Exception e){
            System.out.println(e);
        }
        
        themodel.addAttribute("newFeed", new Feedback());
        themodel.addAttribute("display", result);
        return "feedback"; 
    }
    
    //SHOW PROFILE IF NOT LOGGED OUT
    @GetMapping("/showProfile")
    public String showProfile(){
        return "profileUser";
    }
    
    //EDIT AND UPDATE PERSONAL INFO
    @PostMapping (value = "/updatePersonal")
    public String saveEditPersonalInfo(@ModelAttribute Users u, Model model ) {
        String status = null;
        Users currentUser = (Users) session.getAttribute("currentUser");
        currentUser.setMiddlename(u.getMiddlename());
        currentUser.setLastname(u.getLastname());
        currentUser.setAddress(u.getAddress());
        irawTypeService.saveOrUpdate(currentUser);
        
        status = "Your Personal Information has been Updated.";
        model.addAttribute("status", status);
        return "profileUser";
    }
    
    //EDIT AND UPDATE ACC INFO
    @PostMapping (value = "/updateUserAcc")
    public String saveEditAccnfo(@ModelAttribute Users u, Model model ) {
        String status = null;
        Users currentUser = (Users) session.getAttribute("currentUser");
        currentUser.setEmail(u.getEmail());
        currentUser.setContact(u.getContact());
        irawTypeService.saveOrUpdate(currentUser);
        
        status = "Your Account Details has been Updated.";
        model.addAttribute("status", status);
        return "profileUser";
    }
        
    // UPDATE AND DAVE MEDICAL INFO
    @PostMapping (value = "/updateMedical")
    public String saveEditMedical (@ModelAttribute MedicalRecord mr, @ModelAttribute Users u, Model model){
        String status = null;
        Users currentUser = (Users) session.getAttribute("currentUser"); 
        List<MedicalRecord> medicalRecordExists = irawTypeService.getListSQL("select * from medical_records where uid=:uid", new String[]{"uid"}, new String[]{String.valueOf(currentUser.getUid())}, MedicalRecord.class);
        if(medicalRecordExists.size() > 0 ){
            mr.setMid(medicalRecordExists.get(0).getMid());
        }
        mr.setUid(currentUser.getUid());  
        irawTypeService.saveOrUpdate(mr);
        session.setAttribute("currentUserMed", mr);
        status = "Your Medical Information has been Saved and Updated.";
        model.addAttribute("status", status);
        return "profileUser";
    }
        
    //CHANGE PASSWORD
    @PostMapping (value = "/changepass")
    public String changePassword(@ModelAttribute Users u, Model model, @RequestParam("password") String pass){
        String status = null;
        Users currentUser = (Users) session.getAttribute("currentUser");
        String encryptpass = new Crypto().encryptString(pass);
        currentUser.setPassword(encryptpass);
        irawTypeService.saveOrUpdate(currentUser);

        status = "Your Password has been Changed. ";
        model.addAttribute("status", status);
        return "profileUser";
    }    
    
    @Bean
    public JavaMailSender getJavaMailSender() {
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        mailSender.setHost("smtp.mail.yahoo.com");
        mailSender.setPort(465);

        mailSender.setUsername(MAIL_SERVER_ADDRESS);  
        mailSender.setPassword("ojajzjhnbyfbbgog");   
        
        Properties props = mailSender.getJavaMailProperties();
        props.put("mail.smtp.port", "465");        
        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.ssl","true");
        props.put("mail.smtp.auth", "true"); 

        props.put("mail.debug", "true");

        return mailSender;
    }
    
    public void sendSimpleMessage(JavaMailSender jms, String to, String subject, String text) {
        SimpleMailMessage message = new SimpleMailMessage(); 
        message.setFrom(MAIL_SERVER_ADDRESS);
        message.setTo(to); 
        message.setSubject(subject); 
        message.setText(text);
        jms.send(message);
    }
    
}

