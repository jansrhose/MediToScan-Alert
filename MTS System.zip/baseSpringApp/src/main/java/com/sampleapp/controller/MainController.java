package com.sampleapp.controller;

import com.sampleapp.common.service.IRawTypeService;
import com.sampleapp.entity.Feedback;
import com.sampleapp.entity.Lgus;
import com.sampleapp.entity.Feedback;
import com.sampleapp.entity.Users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping({"/"})
public class MainController {
    @Autowired
    private IRawTypeService rawTypeService;
    
    //Go to Index Page
    @GetMapping("Index")
    public String index(){
        
        // deleting expired alert 1 WEEK 
        
        rawTypeService.executeUpdate("DELETE FROM scannedqr where date_format(STR_TO_DATE(date, '%a %b %d %H:%i:%S SGT %Y'),'%Y-%m-%d') <= CURDATE() - INTERVAL 7 DAY");
        return "index";
    }
    
    //Go to Index Page Also
    @GetMapping("")
    public String index2(){
        
        return "index";
    }
    
    //Go to Feedback
    @GetMapping("Feedback")
    public String feedback(Model model){  
        Feedback emptyFeed = new Feedback();
        model.addAttribute("newFeed", emptyFeed);
        return "feedback";
    }
    
    
    //Go to Login Page
    @GetMapping("Login")
    public String login(){    
        return "login";
    }
    
    //Go to Sign up Page
    @GetMapping("Signup")
    public String signup(Model model){
        Users emptyUser = new Users();
        Lgus emptyLGU = new Lgus();
        model.addAttribute("newUser", emptyUser);
        model.addAttribute("newLGU", emptyLGU);
        return "signup";
    } 
}
