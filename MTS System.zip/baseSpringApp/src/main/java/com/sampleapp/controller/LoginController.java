
package com.sampleapp.controller;

import com.sampleapp.common.service.IRawTypeService;
import com.sampleapp.entity.EmergencyContacts;
import com.sampleapp.entity.Lgus;
import com.sampleapp.entity.MedicalRecord;
import com.sampleapp.entity.Users;
import com.sampleapp.security.Crypto;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;



@Controller
@RequestMapping("/LoginPage")
public class LoginController {
    @Autowired
    private IRawTypeService irawTypeService;
    @Autowired
    private HttpSession currentSession;
    
    
    //LOG OUT
    @GetMapping("/Logout")
    public String logout(){
        currentSession.removeAttribute("currentUser");
        return "login";
    }

    
    //USER PROFILE
    @GetMapping("/ProfileUser")
    public String profilePage(){
        return "profileUser";
    }
    
    
    //FORGOT PASSWORD
    @PostMapping("/forgotPassword")
    public String forgotPassword(HttpServletRequest request, Model model){
        String email = request.getParameter("email");
        String usertype = request.getParameter("usertype");
        String question = request.getParameter("question");
        String answer = request.getParameter("answer");
        String password = request.getParameter("password");
        
        String result;
        
        String usertable = "users";
        Class userclass = Users.class;
        if(usertype.equals("lgu")){
            usertable = "lgus";
            userclass = Lgus.class;
        }
        List emailExists = irawTypeService.getListSQL("SELECT * FROM "+usertable+" where email=:em", new String[]{"em"},new String[]{email}, userclass);
        if(emailExists.size() > 0){
            Users u;
            Lgus l = new Lgus();
            if(usertable.equals("lgu")){
                l = (Lgus)emailExists.get(0);
                u = new Lgus().convertToUsers(l);
            }else{
                u = (Users) emailExists.get(0);
            }
            
            if(u.getAnswer().equals(new Crypto().encryptString(answer)) && u.getQuestion().equals(question)){
                try{
                    String encpassword = new Crypto().encryptString(password);
                    if(usertype.equals("lgu")){
                        l.setPassword(encpassword);
                        irawTypeService.saveOrUpdate(l);
                    }else{
                        u.setPassword(encpassword);
                        irawTypeService.saveOrUpdate(u);
                    }
                    result = "Your Password Has Been Changed";
                }catch(Exception e){
                    result = "Error";
                }
            }else{
                result = "Wrong Security";
            }
            
        }else{
            result = "Email Not Exist.";
        }
        
        model.addAttribute("CPresult",result);
        return "login";
    }
    
    @PostMapping(value="/UserLogin")
    public String verifyUserLogin(Model model, @RequestParam("email") String email, @RequestParam("password") String pword, @RequestParam("usertype") String usertype ){
        String result = null;
        boolean userExist = false;
        String usertable = "users";
        Class userclass = Users.class;
        if(usertype.equals("lgu")){
            usertable = "lgus";
            userclass = Lgus.class;
        }
        String query = "SELECT * FROM "+usertable+" where email=:e and password=:pw";
        String encpword = new Crypto().encryptString(pword);
        List search = new ArrayList<>();
        String page = "";
        search =  irawTypeService.getListSQL(query, new String[]{"e","pw"}, new String[]{email, encpword}, userclass);
        
        if(search.size() > 0 ){
            userExist = true;
            Users loggedInUser;
            if(usertype.equals("lgu")){
                loggedInUser = new Lgus().convertToUsers((Lgus)search.get(0));
                loggedInUser.setStatus(1);
            }else{
                loggedInUser = (Users)search.get(0);
            }
            
            if(loggedInUser.getStatus() == 1){
        
                List<EmergencyContacts> ecs = irawTypeService.getListSQL("SELECT * FROM emergency_contacts where uid='"+loggedInUser.getUid()+"'", EmergencyContacts.class);
                List<MedicalRecord> mr = irawTypeService.getListSQL("SELECT * FROM medical_records where uid='"+loggedInUser.getUid()+"'", MedicalRecord.class);
                currentSession.setAttribute("currentUserMed", !mr.isEmpty() ? mr.get(0):null);
                currentSession.setAttribute("currentECs", ecs);
                currentSession.setAttribute("currentUser", loggedInUser);
                //return "profileUser";
    //            //user session 
                String userType = loggedInUser.getUsertype();

                if(userType.equals("patient") || userType.equals("practitioner")){
                    page = "profileUser";
                } else if (userType.equals("lgu") ){

                    page = "dashboard";
                } 
            }else{
                page = "login";
                result = "Email Not Verified!";
            }
        }else{
            result = "You can not LOGIN! Invalid Input.";
            
            page = "login";
        }
        model.addAttribute("CPresult",result);
//        model.addAttribute("userExist", userExist);
//        if(userExist == false){
//            return "login";
//        }
        //model.addAttribute("CPresult",result);
        return page;
    }
}
