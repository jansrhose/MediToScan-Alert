
package com.sampleapp.listeners;

import com.sampleapp.entity.Users;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class RequestInteceptor extends HandlerInterceptorAdapter {
    
    
    public boolean preHandle(HttpServletRequest request, 	HttpServletResponse response, Object handler) throws Exception {
        
        boolean validAccess = true;

        
        // check how to get current url
        
        
        String url = "";     
        Users currUser = (Users)request.getSession().getAttribute("currentUser");
        if(url.contains("/loginPage")){ // accessible to anyone - add css paths verifyUser...etc
        }else{
//            if(currUser ==null){
//                validAccess = false;
//            }
        }
        
        
        return validAccess;
    }
}
