
package com.sampleapp.listeners;

import java.util.EventListener;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;


@WebListener
public class AppContextListener implements ServletContextListener {
  @Autowired
  private ApplicationContext appContext;
  
  public void contextDestroyed(ServletContextEvent context) {
    System.out.println("Web App is Destroyed.");
  }
  
  public void contextInitialized(ServletContextEvent context) {
    System.out.println("Web App is initialized.");
    ServletContext servletContext = context.getServletContext();
    servletContext.addListener((EventListener)new SessionListener());
    servletContext.setInitParameter("os", "windows");
  }
}
